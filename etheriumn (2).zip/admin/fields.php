<?php
class Fields{
	
	public function __construct(){
		// code here if needed
	}
	
}




?>