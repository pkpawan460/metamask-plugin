	async function metamask() {		
		if (window.ethereum) {console.log('click in metamask');
			window.web3 = new Web3(ethereum);
			try {console.log('i am in try');
			  await ethereum.enable();
			  initPayButtons()
			} catch (err) {console.log('i am in catch');
			  jQuery('#statusblock').html('User denied account access', err);
			}
		  } else if (window.web3) {console.log('i am in elseif');
			window.web3 = new Web3(web3.currentProvider)
			initPayButtons()
		  } else {			jQuery('#statusblock').html('No Metamask (or other Web3 Provider) installed. <a href="https://metamask.io/" target="_blank">Click here</a> the install metamask.');			  		}	}
	
	async function coinbase() {console.log('click in coinbase');
		if (window.ethereum) {
			window.web3 = new Web3(ethereum);
			try {
			  await ethereum.enable();
			  initPayButtons()
			} catch (err) {
			  jQuery('#statusblock').html('User denied account access', err);
			}
		  } else if (window.web3) {
			window.web3 = new Web3(web3.currentProvider.iscoinbase)
			initPayButtons()
		  } else {
			jQuery('#statusblock').html('No Coinbase (or other Web3 Provider) installed');
		  }
    }

    const initPayButtons = () => {
      jQuery('.pay-button').click(() => {
        // paymentAddress is where funds will be send to
        const paymentAddress = '0x192c96bfee59158441f26101b2db1af3b07feb40'
        const amountEth = 1

        web3.eth.sendTransaction({
          to: paymentAddress,
          value: web3.toWei(amountEth, 'ether')
        }, (err, transactionId) => {
          if  (err) {
            console.log('Payment failed', err)
            jQuery('#statusblock').html('Payment failed');
          } else {
            console.log('Payment successful', transactionId)
            jQuery('#statusblock').html('Payment successful');
          }
        })
      })
    }
	
	
	

